var crc32gen_8h =
[
    [ "osmo_crc32gen_check_bits", "group__crcgen.html#gacd9e567dca7fe9704c4a3091fb73f731", null ],
    [ "osmo_crc32gen_compute_bits", "group__crcgen.html#ga38fd8d69d0e56e7ac9c424d9c1201da3", null ],
    [ "osmo_crc32gen_set_bits", "group__crcgen.html#gafd51fe33e5139ac2ac74b235864bc5f6", null ]
];